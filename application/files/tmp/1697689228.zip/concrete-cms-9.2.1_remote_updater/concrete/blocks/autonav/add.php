<?php defined('C5_EXECUTE') or die('Access Denied.');
/** @var \Concrete\Core\Block\View\BlockView $view */

$view->inc('form_setup_html.php', ['info' => [], 'c' => $c ?? null]);
