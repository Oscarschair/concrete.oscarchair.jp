<?php

return [
    'apache' => 'Concrete\Core\Service\HTTP\Apache',
    'nginx' => 'Concrete\Core\Service\HTTP\Nginx',
];
