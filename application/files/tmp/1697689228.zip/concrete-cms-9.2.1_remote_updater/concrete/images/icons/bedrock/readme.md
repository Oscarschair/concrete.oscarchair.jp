These svg files are loaded in from the bedrock dependency using webpack / laravel mix. If you'd like to edit these files
or add new ones, please do so in https://github.com/concrete5/bedrock/tree/master/assets/icons
