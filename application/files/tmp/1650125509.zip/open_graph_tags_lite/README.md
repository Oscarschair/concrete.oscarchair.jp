# Open Graph Tags Lite

![icon](https://raw.github.com/hissy/addon_open_graph_tags_lite/master/icon.png)  
A concrete5 package to insert Open Graph Tags (OGP) inside the HEAD element automatically.

## Install

```bash
$ cd ./packages
$ git clone git@github.com:hissy/addon_open_graph_tags_lite.git open_graph_tags_lite
$ cd ../
$ ./concrete/bin/concrete5 c5:package-install open_graph_tags_lite
```

## License

This package is licensed under the MIT License.
